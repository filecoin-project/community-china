package apitypes

type OpenRPCDocument map[string]interface{}
