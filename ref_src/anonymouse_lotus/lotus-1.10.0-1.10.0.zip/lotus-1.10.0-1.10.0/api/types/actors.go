package apitypes

import "github.com/filecoin-project/go-state-types/network"

type NetworkVersion = network.Version
