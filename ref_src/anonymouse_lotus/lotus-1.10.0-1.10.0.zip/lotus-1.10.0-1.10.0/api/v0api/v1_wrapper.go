package v0api

import (
	"context"

	"github.com/filecoin-project/lotus/chain/types"

	"github.com/ipfs/go-cid"

	"github.com/filecoin-project/go-state-types/abi"

	"github.com/filecoin-project/lotus/api"
	"github.com/filecoin-project/lotus/api/v1api"
)

type WrapperV1Full struct {
	v1api.FullNode
}

func (w *WrapperV1Full) StateSearchMsg(ctx context.Context, msg cid.Cid) (*api.MsgLookup, error) {
	return w.FullNode.StateSearchMsg(ctx, types.EmptyTSK, msg, api.LookbackNoLimit, true)
}

func (w *WrapperV1Full) StateSearchMsgLimited(ctx context.Context, msg cid.Cid, limit abi.ChainEpoch) (*api.MsgLookup, error) {
	return w.FullNode.StateSearchMsg(ctx, types.EmptyTSK, msg, limit, true)
}

func (w *WrapperV1Full) StateWaitMsg(ctx context.Context, msg cid.Cid, confidence uint64) (*api.MsgLookup, error) {
	return w.FullNode.StateWaitMsg(ctx, msg, confidence, api.LookbackNoLimit, true)
}

func (w *WrapperV1Full) StateWaitMsgLimited(ctx context.Context, msg cid.Cid, confidence uint64, limit abi.ChainEpoch) (*api.MsgLookup, error) {
	return w.FullNode.StateWaitMsg(ctx, msg, confidence, limit, true)
}

func (w *WrapperV1Full) StateGetReceipt(ctx context.Context, msg cid.Cid, from types.TipSetKey) (*types.MessageReceipt, error) {
	ml, err := w.FullNode.StateSearchMsg(ctx, from, msg, api.LookbackNoLimit, true)
	if err != nil {
		return nil, err
	}

	if ml == nil {
		return nil, nil
	}

	return &ml.Receipt, nil
}

func (w *WrapperV1Full) Version(ctx context.Context) (api.APIVersion, error) {
	ver, err := w.FullNode.Version(ctx)
	if err != nil {
		return api.APIVersion{}, err
	}

	ver.APIVersion = api.FullAPIVersion0

	return ver, nil
}

var _ FullNode = &WrapperV1Full{}
