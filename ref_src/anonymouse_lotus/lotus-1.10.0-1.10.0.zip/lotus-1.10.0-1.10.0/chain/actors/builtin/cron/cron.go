package cron

import (
	builtin5 "github.com/filecoin-project/specs-actors/v5/actors/builtin"
)

var (
	Address = builtin5.CronActorAddr
	Methods = builtin5.MethodsCron
)
